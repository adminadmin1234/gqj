A Pen created at CodePen.io. You can find this one at https://codepen.io/alexzaworski/pen/mEkvAG.

 Click anywhere. Built with @juliangarnier's anime.js.

...Also basically using his fireworks, which are pretty rad ([and available here]( https://codepen.io/juliangarnier/pen/xOgyjB))